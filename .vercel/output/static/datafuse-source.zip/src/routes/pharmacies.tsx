import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Eye, Pencil, MoreHorizontal, Building2, Search } from "lucide-react";
import { AppShell, StatusBadge } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getUser } from "@/lib/auth";
import { allPharmacies, totals } from "@/lib/mock-data";

export const Route = createFileRoute("/pharmacies")({
  head: () => ({ meta: [{ title: "Pharmacies — DATAFUSE" }] }),
  component: PharmaciesPage,
});

function PharmaciesPage() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");

  useEffect(() => {
    if (typeof window === "undefined") return;
    const u = getUser();
    if (!u) navigate({ to: "/login" });
    else if (u.role !== "admin") navigate({ to: "/" });
  }, [navigate]);

  const list = useMemo(() => {
    const ql = q.toLowerCase().trim();
    return allPharmacies.filter(p => !ql || p.name.toLowerCase().includes(ql) || p.city.toLowerCase().includes(ql));
  }, [q]);

  return (
    <AppShell
      title="Pharmacies du réseau"
      subtitle={`${totals.pharmacies} officines connectées`}
      actions={<>
        <Button variant="outline" size="sm">Exporter</Button>
        <Button size="sm"><Building2 className="mr-2 h-4 w-4" />Ajouter</Button>
      </>}
    >
      <div className="rounded-2xl border border-border bg-card p-4">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Rechercher par nom ou ville…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
        </div>
      </div>

      <div className="mt-4 overflow-hidden rounded-2xl border border-border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-sm">
            <thead className="bg-surface">
              <tr className="text-xs uppercase tracking-wider text-muted-foreground">
                <th className="px-4 py-3 text-left font-medium">Pharmacie</th>
                <th className="px-4 py-3 text-left font-medium">Ville</th>
                <th className="px-4 py-3 text-right font-medium">Inventaire €</th>
                <th className="px-4 py-3 text-right font-medium">Alertes</th>
                <th className="px-4 py-3 text-left font-medium pl-6">Dernière sync</th>
                <th className="px-4 py-3 text-left font-medium">Statut</th>
                <th className="px-4 py-3 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {list.map(p => (
                <tr key={p.id} className="border-t border-border/60 transition-colors hover:bg-surface/60">
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-accent text-[11px] font-semibold text-accent-foreground">
                        {p.name.split(" ").map(w => w[0]).slice(0, 2).join("")}
                      </div>
                      <div>
                        <div className="font-medium">{p.name}</div>
                        <div className="text-[11px] text-muted-foreground">ID #{String(p.id).padStart(4, "0")}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3.5 text-muted-foreground">{p.city}</td>
                  <td className="px-4 py-3.5 text-right tabular-nums font-medium">€{p.inventory.toLocaleString("fr-FR")}</td>
                  <td className="px-4 py-3.5 text-right tabular-nums">
                    <span className={p.alerts > 12 ? "text-destructive font-semibold" : ""}>{p.alerts}</span>
                  </td>
                  <td className="px-4 py-3.5 pl-6 text-muted-foreground text-xs">il y a {p.sync.replace("min ago", "min")}</td>
                  <td className="px-4 py-3.5"><StatusBadge status={p.status} /></td>
                  <td className="px-4 py-3.5">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8"><Eye className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8"><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-3.5 w-3.5" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
